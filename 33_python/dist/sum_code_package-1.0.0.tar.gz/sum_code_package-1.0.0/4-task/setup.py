from setuptools import setup, find_packages

setup(
    name="Sum_code_package",
    version="1.0.0",
    author="Darius",
    description="Simple Python code for packaging",
    packages=find_packages(),
    install_requires=[

    ],
)